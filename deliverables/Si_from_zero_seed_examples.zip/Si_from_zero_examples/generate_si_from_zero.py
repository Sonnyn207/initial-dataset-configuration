"""Generate unrelaxed pure-Si geometric seeds. No DFT, relaxation or MD is run."""
from pathlib import Path
import argparse,json,os
import numpy as np
from ase import Atoms
from ase.build import bulk
from ase.spacegroup import crystal
from ase.io import write
from ase.neighborlist import neighbor_list

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',default='Si_from_zero_seeds');args=p.parse_args()
 out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
 os.environ.setdefault('MPLCONFIGDIR',str(out/'.matplotlib-cache'))
 import atomman as am
 import atomman.unitconvert as uc
 meta=[]
 def save(name,a,origin,extra=None):
  assert set(a.get_chemical_symbols())=={'Si'}
  assert np.isfinite(a.positions).all() and abs(a.get_volume())>0
  ds=neighbor_list('d',a,cutoff=4.0)
  mind=float(ds.min()) if len(ds) else None
  assert mind is None or mind>0.8,(name,mind)
  write(out/(name+'.vasp'),a,format='vasp',direct=True,vasp5=True)
  entry=dict(file=name+'.vasp',atoms=len(a),volume_A3=float(a.get_volume()),min_pair_distance_A=mind,
             origin=origin,relaxed=False,DFT_label_available=False)
  entry.update(extra or {});meta.append(entry)
 a0=5.43
 dc=bulk('Si','diamond',a=a0,cubic=True)
 beta=crystal('Si',[(0,.75,.125)],spacegroup=141,setting=2,cellpar=[4.69,4.69,2.57,90,90,90])
 sh=Atoms('Si',scaled_positions=[[0,0,0]],cell=[[2.55,0,0],[-1.275,2.55*np.sqrt(3)/2,0],[0,0,2.39]],pbc=True)
 bc8=crystal('Si',[(.1003,.1003,.1003)],spacegroup=206,cellpar=[6.64,6.64,6.64,90,90,90])
 assert (len(dc),len(beta),len(sh),len(bc8))==(8,4,1,16)
 for name,a,description in [('dc',dc,'ASE bulk diamond; a0=5.43 A'),('beta_Sn',beta,'I41/amd #141 setting 2; a=4.69,c=2.57 A; initial guess'),('sh',sh,'P6/mmm simple hexagonal; a=2.55,c=2.39 A; initial guess'),('BC8',bc8,'Ia-3 #206; a=6.64 A, 16c u=0.1003; initial guess')]:
  save('Si_'+name+'_prototype',a,description)
 dc64=dc.repeat((2,2,2));dc216=dc.repeat((3,3,3))
 save('Si_dc64',dc64,'2x2x2 conventional diamond');save('Si_dc216',dc216,'3x3x3 conventional diamond')
 v=dc216.copy();del v[0];save('Si_single_vacancy_215',v,'remove site 0 from Si_dc216')
 dd=dc216.get_distances(0,list(range(1,len(dc216))),mic=True)
 j=int(np.argmin(dd))+1
 v2=dc216.copy();del v2[sorted([0,j],reverse=True)];save('Si_divacancy_214',v2,'remove site 0 and a nearest neighbour',dict(removed_sites=[0,j]))
 u=np.array([1.,1.,0.]);u/=np.linalg.norm(u)
 split=dc216.copy();r=split.positions[0].copy();split.positions[0]=r-.9*u;split.append(Atoms('Si',positions=[r+.9*u])[0]);split.wrap()
 save('Si_split_interstitial_217',split,'replace site 0 by two sites separated 1.8 A along [110]; requires relaxation')
 distances=dc216.get_distances(0,list(range(len(dc216))),mic=True)
 target=int(np.argmin(np.abs(np.where(distances>=4.0,distances,np.inf)-6.0)))
 fp=dc216.copy();r=fp.positions[target].copy();fp.positions[target]=r-.9*u;fp.append(Atoms('Si',positions=[r+.9*u])[0]);del fp[0];fp.wrap()
 save('Si_Frenkel_pair_216',fp,'remove site 0 and create split interstitial near a site about 6 A away; may recombine on relaxation',dict(split_site=target,initial_separation_A=float(distances[target])))
 sys=am.System(atoms=am.Atoms(atype=np.ones(len(dc),dtype=int),pos=dc.positions),box=am.Box(vects=dc.cell.array),symbols=['Si'])
 C=am.ElasticConstants(C11=uc.set_in_units(166.,'GPa'),C12=uc.set_in_units(64.,'GPa'),C44=uc.set_in_units(80.,'GPa'))
 for name,line in [('screw',[1,-1,0]),('60deg',[1,0,-1])]:
  d=am.defect.Dislocation(sys,C,[.5,-.5,0],line,[1,1,1],conventional_setting='f')
  base,defect=d.dipole(sizemults=(1,4,4),boxtilt=True,shiftindex=1,return_base_system=True)
  assert defect.natoms==384
  save('Si_'+name+'_dipole_reference',base.dump('ase_Atoms'),'Atomman corresponding dislocation-free tilted reference cell')
  save('Si_'+name+'_dipole_unrelaxed',defect.dump('ase_Atoms'),
       'Atomman Volterra/Stroh periodic dipole, net b=0; two opposite dislocations, anisotropic elasticity; unrelaxed core',
       dict(burgers_in_a_units=[.5,-.5,0],line_uvw=line,slip_hkl=[1,1,1],sizemults=[1,4,4],shiftindex=1,
            elastic_constants_GPa=dict(C11=166,C12=64,C44=80)))
 (out/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 print(json.dumps(dict(files=len(meta),all_geometry_only=True,DFT_run=False,manifest=str(out/'manifest.json'))))
if __name__=='__main__':main()
