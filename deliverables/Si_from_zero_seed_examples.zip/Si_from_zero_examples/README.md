# 无需已有构型的 Si 几何例子

本包14个POSCAR格式 .vasp 文件由代码从晶格参数与原子操作生成，不要求您已有结构文件。
所有结构 relaxed=false、DFT_label_available=false。它们是优化起点，不是训练标签或已证实稳定缺陷。

直接查看：用OVITO / VESTA打开 .vasp。manifest.json记录原子数、来源、最短近邻距离及位错参数。
复现（在可用Python环境中）：

    python -m pip install -r requirements.txt
    python generate_si_from_zero.py --out regenerated

Atomman如从源码安装需要C编译器；本次Linux使用CC=gcc CXX=g++构建成功。

已生成：dc、β-Sn、sh、BC8原型；dc64/216；单空位、双空位、分裂间隙、Frenkel对；螺型和60°周期位错偶极及各自参照。
没有生成：R8、非晶/液态、层错/孪晶/表面、MD轨迹、NEB或任何DFT标签。这些的生成路线见PPT和补充说明。

位错使用Atomman Volterra/Stroh各向异性位移场，C11/C12/C44=166/64/80 GPa只是初始弹性常数。
周期偶极为相反b配对且净b=0；构建例子384原子，shiftindex=1。仍须预弛豫、DFT核验、DXA/位移差分图及尺寸收敛。
中性点缺陷可能在弛豫中重构或复合；保留前驱态时应按实际拓扑标记，不把消失缺陷当作稳定缺陷。

原型参数：dc a=5.43 Å；β-Sn空间群141 setting2，(0,3/4,1/8)，a=4.69,c=2.57 Å；sh空间群191原点，a=2.55,c=2.39 Å；BC8空间群206，16c u=0.1003，a=6.64 Å。均需相应条件下重新优化。
Atomman偶极算法参考Li et al., Physical Review B 70,104113 (2004), doi:10.1103/PhysRevB.70.104113。
